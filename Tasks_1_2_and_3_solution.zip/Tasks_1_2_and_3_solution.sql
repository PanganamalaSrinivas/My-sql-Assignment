# TASK 2: A Find the total and the average sales (display total_sales and avg_sales) 
#Comment: Sales is in the market_fact Table.Below is captured Total Sales and avergae Sales 
select sum(Sales) as 'Total Sales', avg(Sales) as 'Average Sales'
from market_fact;

#Display the number of customers in each region in decreasing order of no_of_customers.
# Task 2B: The result should contain columns Region, no_of_customers 
#Select Region,no_of_customers from customer table group by Region and sort in descending order of count

select Region, count(*) as 'no_of_customers'
from cust_dimen
group by Region
order by count(*) DESC;

#Task 2C. Find the region having maximum customers (display the region name and 
#max(no_of_customers) 
#Region having max count from ALL counts is returned and Grouped by Region

select Region, count(*) as 'max_no_of_customers'
from cust_dimen
group by Region
having max_no_of_customers >= All(select count(*) 
								  from cust_dimen
								  group by Region);
                           
                                  
#Task 2D : Find the number and id of products sold in decreasing order of products sold 
#(display product id, #no_of_products sold) 
#Here I Group by product id after joinging the market_fact Table which has prod idss sold and return the count of products sold per product id in Decreasing order 

select p.Prod_id, count(m.Prod_id) as 'no_of_products_sold'
from prod_dimen p inner join market_fact m on p.Prod_id=m.Prod_id
group by Prod_id
order by no_of_products_sold DESC;   

#Task 2E: Find all the customers from Atlantic region who have ever purchased ‘TABLES’ 
#and the number of tables purchased 
#(display the customer name, no_of_tables purchased)  

#Product SUB CATEGORY HAS TABLES. JOIN IS between PROD_DIMEN,MARKET_FACT AND CUST_DIMEN
#COUNT OF TABLES IS RETURNED REGION IS 'ATLANTIC'

select c.Customer_Name as 'Customer Name',count(p.Product_Sub_Category) as 'no_of_tables purchased'
from prod_dimen p inner join market_fact m on p.Prod_id=m.Prod_id
                  inner join cust_dimen c on c.Cust_id=m.Cust_id
where p.Product_Sub_Category = 'TABLES' and c.Region='ATLANTIC';

#Task 3A: A. Display the product categories in descending order of profits 
#(display the product category wise profits i.e. product_category, profits)? 
#Join Key FOR INNER JOIN is Product Id  on Market fact and Product Table. Profit is sorted in Descending order

select p.Product_Category, sum(m.Profit) 'Profit per Product Category'
from prod_dimen p inner join market_fact m on p.Prod_id=m.Prod_id
Group by p.Product_Category
order by sum(m.Profit) DESC;

#B. Display the product category, product sub-category and the profit within 
#each subcategory in three columns.
#The product category and sub category are used to Group by and profit is sorted in DESC order 

select p.Product_Category, p.Product_Sub_Category,sum(m.Profit) 'Profit per Product sub Category'
from prod_dimen p inner join market_fact m on p.Prod_id=m.Prod_id
Group by p.Product_Category,Product_Sub_Category
order by sum(m.Profit) DESC;
 
#C. [1]Where is the least profitable product subcategory shipped the most? 
#Answer: NUNAVUT
#There is a 4 Table join between Market_fact that provides Profit
#Product_dimen that provides the Product sub Category and Shipping Table that provides the shipping count
#The  max for Shipping count is found and the Profit is sorted in Ascending order leaving the
#first row as the Minimum Profit. Cus_dimen supplies Region

select c.Region,p.Product_Sub_Category,sum(m.Profit) as 'Profit', count(s.Ship_id) as 'No of shipments'
from shipping_dimen s inner join market_fact m on s.Ship_id=m.Ship_id 
                      inner join cust_dimen c on m.Cust_id=c.Cust_id
                      inner join prod_dimen p on m.Prod_id=p.Prod_id
group by s.Ship_Mode
having count(s.Ship_id) >= All(select count(Ship_id)
                                  from shipping_dimen
                                  group by Ship_Mode)
order by sum(m.Profit) ASC; 

                                  
 #Comments: There is a 4 Table join. Group by Region, return the least profitable sub category
 #and Region wise profits which is sum(Profit) over Region and number of shipments by Region. Region wise Profits are displayed in descending order
 
#For the least profitable product sub-category, display the  region-wise no_of_shipments 
#and the profit made in each region in decreasing order of profits 
#(i.e. region, no_of_shipments, profit_in_each_region) o Note: 
#You can hardcode the name of the least profitable product subcategory  

 select c.Region, p.Product_Sub_Category as 'Least Profitable Product Sub Category',count(s.Ship_id) as 'no_of_shipments', sum(m.Profit) as 'Region wise Profit'
 from market_fact m inner join cust_dimen c on m.Cust_id=c.Cust_id
					inner join prod_dimen p on m.Prod_id=p.Prod_id
                    inner join shipping_dimen s on m.Ship_id=s.Ship_id
 Group by c.Region
 having sum(m.profit) <= all (select sum(profit) from market_fact)
 order by sum(m.Profit) DESC;
 
 #Task 1A: A. Describe the data in hand in your own words. (Word Limit is 500) 
select * from cust_dimen;
# cust_dimen has Customer_Names like Skye Norling and Doug Bickford , Provinces and Regions such as NUNAVUT and Northwest Territories and Customer_Segments such as Corporate and consumer and Cust_ids suchas Cust 1, to more than Cust 999
#It is a Dimension Table. It has 1832 rows
#All fields are text fields
 desc cust_dimen; 
 select count(*) from cust_dimen;
 desc market_fact;
 select * from market_fact;
 select count(*) from market_fact;
 #market_fact is the Fact Table and has Ord_id, Prod_ids such as 4,17,6 etc;Ship_id such as SHP 7609 and Cust_ids such as 1818 and sales Data and Discount and Order_Quantity and Profit and Shipping_Cost and Product_Base_Margins
 #It has 8336 rows. All the Facts are double precision except for Order_quantity which is an integer
 #All other fields are text fields
 
 desc orders_dimen;
 select * from orders_dimen;
 select count(*) from orders_dimen;
 #orders_dimen has Order_Ids like 3,293 and Order_dates and Order_priroity LOW HIGH NOT SPECIFIED and Ord_ids such as Ord 1, Ord 2 etc;
 #Its is a Dimension Table. It has 5506 rows. Except for Order_ID
 #whcih is an int(11) all fields are text fields.
 desc prod_dimen;
 select * from prod_dimen;
 select count(*) from prod_dimen;
 #Prod_dimen has Product_Categorys like Technology, Furniture and Office Supplies and Product Sub Catories like Paper, Rubber bands, appliances etc; and Prod_ids like Prod 1, Prod 2 etc;
 #It is a dimension Table. It has 17 rows.All fields are text fields.
 desc shipping_dimen;
 select * from shipping_dimen;
 select count(*) from shipping_dimen;
 #shipping_dimen has fields like Order_ID and ship_mode LIKE REGULAR AIR, DELIVERY TRUCK and Ship_Dates and ship_ids like SHP 1, SHP 2 etc;
 #It is a Dimension Table. It has 7701 rows of data.All fields except for Order-id which is int(11) are text fields.

 #Task 1B:Identify and list the Primary Keys and Foreign Keys for this dataset 
 #(Hint: If a table don’t have Primary Key or Foreign Key, 
 #then specifically mention it in your answer.) 
 
 #Answer 1 B: The Tables given do not have a PK or FK defined explicitly.
 #However PKs that can be inferred are as follows:
 # Cust_id text field can be used as a PK
 #Inferred Foreign Key to cust_dimen is via market_fact Cust_id
 #and via market_fact Prod_id to prod_dimen
 #For market_fact the PK inferred is Ord_id. Fks inferred are
 #Prod_id to Prod_dimen and Order_id to orders_dimen and Ship_id to
 #shipping_dimen
 #For orders_dimen the inferred PK is Order_ID The FK to market_fact is Ord_id
 #For prod_dimen the inferred PK is Prod_id This has an inferred FK to market_fact Prod_id
 #For shipping_dimen the PK inferred is Ship_id and the inferred FK to orders_dimen is Order_ID
 #The fields for all Tables are Nullable.

